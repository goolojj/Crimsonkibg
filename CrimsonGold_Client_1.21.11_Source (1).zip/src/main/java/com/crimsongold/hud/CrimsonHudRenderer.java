package com.crimsongold.hud;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;

public class CrimsonHudRenderer {
    private static float prevYaw = 0f;
    private static float prevPitch = 0f;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        if (cfg == null) return;

        // Motion Blur velocity vignette
        if (cfg.motionBlurEnabled) {
            float yawDiff = Math.abs(mc.player.getYaw() - prevYaw);
            float pitchDiff = Math.abs(mc.player.getPitch() - prevPitch);
            float speed = Math.min(1.0f, (yawDiff + pitchDiff) / 28.0f);
            if (speed > 0.04f) {
                int alpha = (int) (speed * cfg.motionBlurStrength * 110);
                int col = (alpha << 24) | 0x180810;
                ctx.fill(0, 0, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), col);
            }
            prevYaw = mc.player.getYaw();
            prevPitch = mc.player.getPitch();
        }

        if (!cfg.hudEnabled) return;

        // Top-Left CrimsonGold Pill: FPS + Coords + CPS
        String fpsText = "§6FPS §f" + mc.getCurrentFps();
        String coords = String.format("§6XYZ §f%d %d %d",
                (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
        String cpsText = cfg.cpsCounterEnabled
                ? "  §cCPS §f" + CrimsonGoldClient.getLeftCps() + " | " + CrimsonGoldClient.getRightCps()
                : "";
        String line = fpsText + "  §8|  " + coords + cpsText;

        int boxW = mc.textRenderer.getWidth(line) + 12;
        ctx.fill(6, 6, 6 + boxW, 22, 0xB80B0A10);
        drawBoxBorder(ctx, 6, 6, boxW, 16, 0xFFC41E44);
        ctx.drawTextWithShadow(mc.textRenderer, line, 12, 10, 0xFFFFFF);

        // Target Hitbox Info Pill (Top-Center)
        if (cfg.hitboxEnabled && mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity target = ehr.getEntity();
            String hp = (target instanceof LivingEntity le)
                    ? String.format(" §c%.1f❤", le.getHealth())
                    : "";
            String dist = String.format(" §7[%.1fm]", mc.player.distanceTo(target));
            String tLine = "§6" + target.getName().getString() + hp + dist;
            int tw = mc.textRenderer.getWidth(tLine) + 12;
            int tx = (mc.getWindow().getScaledWidth() - tw) / 2;
            ctx.fill(tx, 6, tx + tw, 22, 0xB80B0A10);
            drawBoxBorder(ctx, tx, 6, tw, 16, 0xFFFFD466);
            ctx.drawTextWithShadow(mc.textRenderer, tLine, tx + 6, 10, 0xFFFFFF);
        }

        // Keystrokes
        if (cfg.keystrokesEnabled) {
            int kx = 6;
            int ky = 28;
            drawKey(ctx, mc, kx + 22, ky, 20, 18, "W", mc.options.forwardKey.isPressed());
            drawKey(ctx, mc, kx, ky + 20, 20, 18, "A", mc.options.leftKey.isPressed());
            drawKey(ctx, mc, kx + 22, ky + 20, 20, 18, "S", mc.options.backKey.isPressed());
            drawKey(ctx, mc, kx + 44, ky + 20, 20, 18, "D", mc.options.rightKey.isPressed());
            drawKey(ctx, mc, kx, ky + 40, 31, 16, "LMB", mc.options.attackKey.isPressed());
            drawKey(ctx, mc, kx + 33, ky + 40, 31, 16, "RMB", mc.options.useKey.isPressed());
        }

        // Armor HUD (Bottom-Right)
        if (cfg.armorHudEnabled) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int ax = sw - 24;
            int ay = sh - 22;
            EquipmentSlot[] slots = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
            for (EquipmentSlot slot : slots) {
                ItemStack stack = mc.player.getEquippedStack(slot);
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, ax, ay);
                    ctx.drawStackOverlay(mc.textRenderer, stack, ax, ay);
                }
                ay -= 18;
            }
        }
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xCCFFD466 : 0xB00B0A10;
        int border = pressed ? 0xFFFFFFFF : 0xFFC41E44;
        int txtCol = pressed ? 0xFF100810 : 0xFFFFFFFF;
        ctx.fill(x, y, x + w, y + h, bg);
        drawBoxBorder(ctx, x, y, w, h, border);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, txtCol, false);
    }

    private static void drawBoxBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }
}
